library(ggplot2)
library(scales)
library(reshape2)
library(extrafont)
library(grid)
library(gridExtra)

# library(pheatmap)
# extrafont::font_import()
fonts()



ppi= 500
cbpl_7 <- c("#377eb8", "#4daf4a", "#984ea3", "#ff7f00", 
            "#999999", "#a65628", "#f781bf")


# =========================================== heatmap
pdata_mat <- read.table("fig5_heatmap.txt", sep = "\t", header = T, stringsAsFactors = F)
as.vector(pdata_mat$Drug_name)
pdata_mat$Drug_name <- factor(pdata_mat$Drug_name,
                              ordered=TRUE,
                              levels = rev(c("Hydromorphone", "Naltrexone", "Oxycodone",
                                             "Oxycodone hydrochloride", "Oxymorphone")))


pdata_mat_label <- pdata_mat[, c(1,2)]

pdata_mat_heat <- pdata_mat[, -2]
colnames(pdata_mat_heat) <- c("Drug_name", 0:63)

# =========================
pdata_mat_heat_m <- melt(pdata_mat_heat)

p_heat <- ggplot(pdata_mat_heat_m, aes(x = variable, y = Drug_name, fill = value)) +
  geom_tile(color = "black") +
  # geom_text(aes(label = value), color = "white", size = 0.5, family="Arial") +
  coord_fixed() +
  theme(legend.position = "right",
        legend.title = element_blank(),
        text=element_text(size = 7, family = "Arial"),
        axis.text = element_text(size = 6), 
        plot.title = element_text(size = 8, hjust = 0.5)) +
  scale_y_discrete(breaks = rev(c("Hydromorphone", "Naltrexone", "Oxycodone",
                                  "Oxycodone hydrochloride", "Oxymorphone")),
                   labels = rev(c("Hydromorphone", "Naltrexone", "Oxycodone",
                                  "Oxycodone hydrochloride", "Oxymorphone"))) +
  scale_x_discrete(breaks = seq(0, 63, 4),
                   labels = seq(0, 63, 4)) +
  ylab("Drug") +
  xlab("Index") + 
  ggtitle("GNN attention score") + 
  scale_fill_gradient2(low = "#2b83ba",
                       mid = "#ffffff",
                       high = "#d7191c") +
  guides(fill = guide_colourbar(barwidth = 0.5,
                                barheight = 2.5))
# p_heat


pdata_mat_label_m <- melt(pdata_mat_label)
p_label <- ggplot(pdata_mat_label_m, aes(x = variable, y = Drug_name, fill = value)) +
  geom_tile(color = "black") +
  geom_text(aes(label = value), color = "black", size = 2, family="Arial") +
  coord_fixed() +
  theme(legend.position = "right",
        legend.title = element_blank(),
        text=element_text(size = 7, family = "Arial"),
        axis.text = element_text(size = 6), 
        plot.title = element_text(size = 8, hjust = 0.5)) +
  scale_y_discrete(breaks = rev(c("Hydromorphone", "Naltrexone", "Oxycodone",
                                  "Oxycodone hydrochloride", "Oxymorphone")),
                   labels = rev(c("Hydromorphone", "Naltrexone", "Oxycodone",
                                  "Oxycodone hydrochloride", "Oxymorphone"))) +
  ylab("Drug") +
  xlab("") + 
  ggtitle("") + 
  scale_fill_gradient(low = "#d8b365", high = "#5ab4ac") +
  guides(fill = guide_colourbar(barwidth = 0.5,
                                barheight = 2))

# p_label


# =========================================== roc, pr
cbpl_5 <- c("#1b9e77", "#d95f02", "#7570b3", "#e7298a", "#66a61e")

p2data_rocpr1 <- read.table("fig5_roc_pr_1.txt", 
                           header = T, sep = "\t", stringsAsFactors = F)
colnames(p2data_rocpr1) <- c("Drug_name", "metric", "x", "y")
drug_names <- unique(p2data_rocpr1$Drug_name)


p2_roc1 <- ggplot() + 
  geom_line(data = p2data_rocpr1[p2data_rocpr1$metric == "AUC" & 
                                   p2data_rocpr1$Drug_name == drug_names[1], ], 
            aes(x = x, y = y, color = "1")) +
  geom_line(data = p2data_rocpr1[p2data_rocpr1$metric == "AUC" & 
                                   p2data_rocpr1$Drug_name == drug_names[2], ], 
            aes(x = x, y = y, color = "2")) +
  geom_line(data = p2data_rocpr1[p2data_rocpr1$metric == "AUC" & 
                                   p2data_rocpr1$Drug_name == drug_names[3], ], 
            aes(x = x, y = y, color = "3")) +
  geom_line(data = p2data_rocpr1[p2data_rocpr1$metric == "AUC" & 
                                   p2data_rocpr1$Drug_name == drug_names[4], ], 
            aes(x = x, y = y, color = "4")) +
  geom_line(data = p2data_rocpr1[p2data_rocpr1$metric == "AUC" & 
                                   p2data_rocpr1$Drug_name == drug_names[5], ], 
            aes(x = x, y = y, color = "5")) +
  geom_abline(intercept = 0, slope = 1, linetype = "dashed", color = "grey") +
  scale_color_manual(values = c("1" = cbpl_5[1], "2" = cbpl_5[2], 
                                "3" = cbpl_5[3], "4" = cbpl_5[4], 
                                "5" = cbpl_5[5]), 
                     labels = drug_names) +
  theme_bw() + 
  theme(# legend.position = c(0.64, 0.33),
        legend.position = "bottom", 
        legend.title = element_blank(),
        legend.margin=margin(-10, 0, -10, 0),
        legend.key.size = unit(0.35, "cm"),
        legend.text = element_text(size=7, family = "Arial"),
        text = element_text(size = 7, family = "Arial"),
        plot.title = element_text(hjust=0.5, family = "Arial"),
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1),
  ) +
  scale_x_continuous(limits = c(0, 1),
                     breaks = seq(0, 1, 0.2), 
                     expand = c(0, 0)) +
  scale_y_continuous(limits = c(0, 1),
                     breaks = seq(0, 1, 0.2), 
                     expand = c(0, 0)) +
  labs(title = "ROC", y = "True positive rate", x = "False positive rate")
# p2_roc1


p2_aupr1 <- ggplot() + 
  geom_line(data = p2data_rocpr1[p2data_rocpr1$metric == "AUPR" & 
                                   p2data_rocpr1$Drug_name == drug_names[1], ], 
            aes(x = x, y = y, color = "1")) +
  geom_line(data = p2data_rocpr1[p2data_rocpr1$metric == "AUPR" & 
                                   p2data_rocpr1$Drug_name == drug_names[2], ], 
            aes(x = x, y = y, color = "2")) +
  geom_line(data = p2data_rocpr1[p2data_rocpr1$metric == "AUPR" & 
                                   p2data_rocpr1$Drug_name == drug_names[3], ], 
            aes(x = x, y = y, color = "3")) +
  geom_line(data = p2data_rocpr1[p2data_rocpr1$metric == "AUPR" & 
                                   p2data_rocpr1$Drug_name == drug_names[4], ], 
            aes(x = x, y = y, color = "4")) +
  geom_line(data = p2data_rocpr1[p2data_rocpr1$metric == "AUPR" & 
                                   p2data_rocpr1$Drug_name == drug_names[5], ], 
            aes(x = x, y = y, color = "5")) +
  scale_color_manual(values = c("1" = cbpl_5[1], "2" = cbpl_5[2], 
                                "3" = cbpl_5[3], "4" = cbpl_5[4], 
                                "5" = cbpl_5[5]), 
                     labels = drug_names) +
  theme_bw() + 
  theme(legend.position = c(0.37, 0.33),
        legend.title = element_blank(),
        legend.margin=margin(-10, 0, -10, 0),
        legend.key.size = unit(0.35, "cm"),
        legend.text = element_text(size=5, family = "Arial"),
        text = element_text(size = 7, family = "Arial"),
        plot.title = element_text(hjust=0.5, family = "Arial"),
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1),
  ) +
  scale_x_continuous(limits = c(0, 1),
                     breaks = seq(0, 1, 0.2), 
                     expand = c(0, 0)) +
  scale_y_continuous(limits = c(0, 1),
                     breaks = seq(0, 1, 0.2), 
                     expand = c(0, 0)) +
  labs(title = "PR", y = "Precision", x = "Recall")
# p2_aupr1



# =========================================== roc, pr 2
p2data_rocpr2 <- read.table("fig5_roc_pr_2.txt", 
                            header = T, sep = "\t", stringsAsFactors = F)
p2data_rocpr2_m <- melt(p2data_rocpr2, id.vars = c("Drug_name", "metric"))
# p2data_rocpr2_m <- p2data_rocpr2_m[p2data_rocpr2_m$value != 0, ]

p2data_rocpr2_m$variable <- factor(p2data_rocpr2_m$variable, levels = c("DE", "LT", "HO", "DS", 
                                                                         "CA", "RI", "OT"))

p2_bar_auc_2 <- ggplot(data = p2data_rocpr2_m[p2data_rocpr2_m$metric == "AUC", ], 
                   aes(x=variable, y=value, fill=variable)) +
  geom_bar(stat="identity", position=position_dodge(0.9),
           colour="black", size=0.2) + 
  facet_grid(.~Drug_name, scales = "free", space = "free_y") + 
  theme_bw() +  
  theme(legend.position = "none", 
        text=element_text(size = 7, family = "Arial"), 
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1),
        axis.text.x = element_text(angle = 0),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(), 
        plot.title = element_text(size=8, hjust = 0.5)) +
  scale_fill_manual(values = cbpl_7) + 
  scale_y_continuous(limits=c(0, 1), 
                     breaks=seq(0, 1, 0.2), 
                     expand = c(0, 0)) + 
  xlab("") + 
  ylab("") + 
  ggtitle("AUC")
# p2_bar_auc_2

p2_bar_aupr_2 <- ggplot(data = p2data_rocpr2_m[p2data_rocpr2_m$metric == "AUPR", ], 
                       aes(x=variable, y=value, fill=variable)) +
  geom_bar(stat="identity", position=position_dodge(0.9),
           colour="black", size=0.2) + 
  facet_grid(.~Drug_name, scales = "free", space = "free_y") + 
  theme_bw() +  
  theme(legend.position = "none", 
        text=element_text(size = 7, family = "Arial"), 
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1),
        axis.text.x = element_text(angle = 0),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(), 
        plot.title = element_text(size=8, hjust = 0.5)) +
  scale_fill_manual(values = cbpl_7) + 
  scale_y_continuous(limits=c(0, 0.61), 
                     breaks=seq(0, 1, 0.1), 
                     expand = c(0, 0)) + 
  xlab("") + 
  ylab("") + 
  ggtitle("AUPR")
# p2_bar_aupr_2


g_legend<-function(a.gplot){
  tmp <- ggplot_gtable(ggplot_build(a.gplot))
  leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
  legend <- tmp$grobs[[leg]]
  return(legend)}
p2_1_legend <- g_legend(p2_roc1)


png("fig5_heatmap_etc.raw.png",
    width = 16,
    height = 3 + 6 + 0.5 + 0.5 + 4.5 + 4.5, units = "cm", res=ppi)
grid.arrange(p_heat, 
             arrangeGrob(grid.rect(gp=gpar(col="white")),
                         p2_roc1 + theme(legend.position = "none"), 
                         grid.rect(gp=gpar(col="white")),
                         p2_aupr1 + theme(legend.position = "none"),
                         grid.rect(gp=gpar(col="white")),
                         ncol=5, 
                         widths =c(1.5, 6, 1, 6, 1.5)), 
             p2_1_legend,
             grid.rect(gp=gpar(col="white")),
             arrangeGrob(grid.rect(gp=gpar(col="white")),
                         p2_bar_auc_2 + theme(legend.position = "none"),
                         grid.rect(gp=gpar(col="white")), 
                         ncol = 3, 
                         widths =c(1, 14, 1)),
             arrangeGrob(grid.rect(gp=gpar(col="white")),
                         p2_bar_aupr_2 + theme(legend.position = "none"),
                         grid.rect(gp=gpar(col="white")), 
                         ncol = 3, 
                         widths =c(1, 14, 1)),
             nrow = 6,
             heights = c(3, 6, 0.5, 0.5, 4.5, 4.5))
dev.off()


png("fig5_heatmap.label.raw.png",
    width = 6,
    height = 3, units = "cm", res=ppi)
p_label
dev.off()








# # heatmap ===============================
# heatmap_dm <- function(mat,rowdt){
#   pheatmap(mat, cluster_rows=F, show_rownames=T, cluster_cols=F, annotation_row = rowdt,
#            main = "GNN attention score", scale = "none")
# }
# 

# 
# # --------------------
# rownames(pdata_mat_heat) <- pdata_mat_heat$Drug_name
# pdata_mat_heat <- pdata_mat_heat[, -1]
# p_heat <- heatmap_dm(pdata_mat_heat, pdata_mat_label)




