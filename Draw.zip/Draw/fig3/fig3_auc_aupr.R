library(ggplot2)
library(scales)
library(reshape2)
library(extrafont)
library(grid)
library(gridExtra)

library(ggforce)
library(stringr)


ppi= 500

cbpl_7 <- c("#377eb8", "#4daf4a", "#984ea3", "#ff7f00", 
            "#999999", "#a65628", "#f781bf")



# -----------------------auc
pdata_auc <- read.table("fig3_1.auc.txt", header = T, sep = "\t", stringsAsFactors = F)
pdata_aucm <- melt(pdata_auc, id.vars = c("test"))
pdata_aucm$variable <- factor(pdata_aucm$variable, levels = c("task1", 
                                                              "DE", "LT", "HO", "DS", 
                                                                "CA", "RI", "OT"))

max(pdata_aucm$value)
min(pdata_aucm$value)
p_auc_1 <- ggplot(data=pdata_aucm[pdata_aucm$variable == "task1", ]) + 
  geom_sina(aes(variable, value, 
                colour = "#e41a1c"), scale="width", maxwidth=1, size=0.7) +
  theme_bw() + 
  theme(legend.position = "none", 
        text = element_text(size = 7, family = "Arial"),
        plot.title = element_text(hjust=0.5, family = "Arial"),
        panel.border = element_blank(), 
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1), 
        panel.grid.minor = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 2),
        ) +
  scale_x_discrete(labels = c("Serious")) +
  scale_y_continuous(limits = c(0.85, 0.975),
                     breaks = seq(0.85, 1, 0.025),
                     labels = format(round(seq(0.85, 1, 0.025), 3), nsmall = 3), ) +
  labs(title = "Task1", y = "AUC", x = NULL)
# p_auc_1

p_auc_2 <- ggplot(data=pdata_aucm[pdata_aucm$variable != "task1", ]) + 
  geom_sina(aes(variable, value, 
                colour = variable), scale="width", maxwidth=0.8, size=0.7) +
  theme_bw() + 
  theme(legend.position = "none", 
        text = element_text(size = 7, family = "Arial"),
        plot.title = element_text(hjust=0.5, family = "Arial"),
        panel.border = element_blank(), 
        axis.text.y = element_blank(), 
        axis.ticks.y = element_blank(), 
        axis.title.y = element_blank(), 
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1), 
        panel.grid.minor = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 2),) +
  scale_color_manual(values = cbpl_7) + 
  scale_x_discrete(labels = function(x) str_wrap(x, width = 1)) +
  scale_y_continuous(limits = c(0.85, 0.975),
                     breaks = seq(0.85, 1, 0.025),
                     labels = format(round(seq(0.85, 1, 0.025), 3), nsmall = 3), ) +
  labs(title = "Task2", y = "AUC", x = NULL)
# p_auc_2



# -----------------------aupr
pdata_aupr <- read.table("fig3_1.aupr.txt", header = T, sep = "\t", stringsAsFactors = F)
pdata_auprm <- melt(pdata_aupr, id.vars = c("test"))
pdata_auprm$variable <- factor(pdata_auprm$variable, levels = c("task1", 
                                                                "DE", "LT", "HO", "DS", 
                                                                  "CA", "RI", "OT"))

max(pdata_auprm$value)
min(pdata_auprm$value)
p_aupr_1 <- ggplot(data=pdata_auprm[pdata_auprm$variable == "task1", ]) + 
  geom_sina(aes(variable, value, 
                colour = "#e41a1c"), scale="width", maxwidth=1, size=0.7) +
  theme_bw() + 
  theme(legend.position = "none", 
        text = element_text(size = 7, family = "Arial"),
        plot.title = element_text(hjust=0.5, family = "Arial"),
        panel.border = element_blank(), 
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1), 
        panel.grid.minor = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 2),
  ) +
  scale_x_discrete(labels = c("Serious")) +
  scale_y_continuous(limits = c(0.39, 0.95),
                     breaks = seq(0.40, 0.95, 0.1),
                     labels = format(round(seq(0.40, 0.95, 0.1), 3), nsmall = 3), ) +
  labs(title = "Task1", y = "AUPR", x = NULL)
# p_aupr_1

p_aupr_2 <- ggplot(data=pdata_auprm[pdata_auprm$variable != "task1", ]) + 
  geom_sina(aes(variable, value, 
                colour = variable), scale="width", maxwidth=0.8, size=0.7) +
  theme_bw() + 
  theme(legend.position = "none", 
        text = element_text(size = 7, family = "Arial"),
        plot.title = element_text(hjust=0.5, family = "Arial"),
        panel.border = element_blank(), 
        axis.text.y = element_blank(), 
        axis.ticks.y = element_blank(), 
        axis.title.y = element_blank(), 
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1), 
        panel.grid.minor = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 2),) +
  scale_color_manual(values = cbpl_7) + 
  scale_x_discrete(labels = function(x) str_wrap(x, width = 1)) +
  scale_y_continuous(limits = c(0.39, 0.95),
                     breaks = seq(0.40, 0.95, 0.1),
                     labels = format(round(seq(0.40, 0.95, 0.1), 3), nsmall = 3), ) +
  labs(title = "Task2", y = "AUPR", x = NULL)
# p_aupr_2





cbpl_2 <- c("#e66101", "#fdb863")

# SIDER: AUC: 0.945, AUPR: 0.908
# OFFSIDES: AUC 0.937, AUPR:0.931
# ----------------------- ROC
p2data_auroc <- read.table("fig3_2.auroc.txt", header = T, sep = "\t", stringsAsFactors = F)

p2_auroc <- ggplot() + 
  geom_line(data = p2data_auroc[p2data_auroc$dataset=="SIDER", ], 
            aes(x = x, y = y, color = "1")) +
  geom_line(data = p2data_auroc[p2data_auroc$dataset=="OFFSIDES", ], 
            aes(x = x, y = y, color = "2")) +
  geom_abline(intercept = 0, slope = 1, linetype = "dashed", color = "grey") +
  scale_color_manual(name = "Lines",
                     values = c("1" = cbpl_2[1], "2" = cbpl_2[2]),
                     labels = c("SIDER (AUC = 0.945)", 
                                "OFFSIDES (AUC = 0.937)")) +
  theme_bw() + 
  theme(legend.position = c(0.63, 0.13),
        legend.title = element_blank(),
        legend.margin=margin(-10, 0, -10, 0),
        legend.key.size = unit(0.35, "cm"),
        legend.text = element_text(size=5, family = "Arial"),
        text = element_text(size = 7, family = "Arial"),
        plot.title = element_text(hjust=0.5, family = "Arial"),
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1),
        ) +
  scale_x_continuous(limits = c(0, 1),
                     breaks = seq(0, 1, 0.2), 
                     expand = c(0, 0)) +
  scale_y_continuous(limits = c(0, 1),
                     breaks = seq(0, 1, 0.2), 
                     expand = c(0, 0)) +
  labs(title = "ROC", y = "True positive rate", x = "False positive rate")
# p2_auroc


# ----------------------- PR
p2data_aupr <- read.table("fig3_2.aupr.txt", header = T, sep = "\t", stringsAsFactors = F)

p2_aupr <- ggplot() + 
  geom_line(data = p2data_aupr[p2data_aupr$dataset=="SIDER", ], 
            aes(x = x, y = y, color = "1")) +
  geom_line(data = p2data_aupr[p2data_aupr$dataset=="OFFSIDES", ], 
            aes(x = x, y = y, color = "2")) +
  geom_abline(intercept = 1, slope = -1, linetype = "dashed", color = "grey") +
  scale_color_manual(name = "Lines",
                     values = c("1" = cbpl_2[1], "2" = cbpl_2[2]),
                     labels = c("SIDER (AUPR = 0.908)", 
                                "OFFSIDES (AUPR = 0.931)")) +
  theme_bw() + 
  theme(legend.position = c(0.38, 0.13),
        legend.title = element_blank(),
        legend.margin=margin(-10, 0, -10, 0),
        legend.key.size = unit(0.35, "cm"),
        legend.text = element_text(size=5, family = "Arial"),
        text = element_text(size = 7, family = "Arial"),
        plot.title = element_text(hjust=0.5, family = "Arial"),
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1),
  ) +
  scale_x_continuous(limits = c(0, 1),
                     breaks = seq(0, 1, 0.2), 
                     expand = c(0, 0)) +
  scale_y_continuous(limits = c(0, 1),
                     breaks = seq(0, 1, 0.2), 
                     expand = c(0, 0)) +
  labs(title = "PR", y = "Precision", x = "Recall")
# p2_aupr



# ----------------------- task2 duliji
p2data_bar <- read.table("fig3_2.7classes.aurocpr.txt", header = T, 
                         sep = "\t", stringsAsFactors = F)
colnames(p2data_bar) <- c("dataset", "mtype", "class", "value")
p2data_bar$dataset <- factor(p2data_bar$dataset, levels = c("SIDER", "OFFSIDES"))
p2data_bar$class <- factor(p2data_bar$class, levels = c("DE", "LT", "HO", "DS", 
                                                         "CA", "RI", "OT"))

p2_bar_1 <- ggplot(data = p2data_bar[p2data_bar$mtype=="AUC", ], 
                   aes(x=class, y=value, fill=dataset)) +
  geom_bar(stat="identity", position=position_dodge(0.9),
           colour="black", size=0.1, width = 0.75) + 
  theme_bw() +  
  theme(legend.position = "bottom", 
        legend.title = element_blank(),
        legend.key.size = unit(0.25, "cm"),
        legend.text = element_text(size=6, family = "Arial"),
        legend.margin=margin(-7, 0, 0, 0),
        text=element_text(size = 7, family = "Arial"), 
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1),
        axis.text.x = element_text(angle = 0),
        axis.title.x = element_text(size = 7),
        axis.title.y = element_blank(), 
        plot.title = element_text(size=8, hjust = 0.5)) +
  scale_fill_manual(values = cbpl_2, 
                    labels = c("SIDER     ", "OFFSIDES")) + 
  scale_y_continuous(limits=c(0, 1), 
                     breaks=seq(0, 1, 0.2), 
                     expand = c(0, 0)) + 
  coord_cartesian(ylim = c(0.2, 1)) + 
  # geom_hline(yintercept=mean(p2data_bar[p2data_bar$mtype=="AUC", ]$value), 
  #            linetype='dashed', col = 'black') +
  xlab("") + 
  ylab("") + 
  ggtitle("AUC")
# p2_bar_1

p2_bar_2 <- ggplot(data = p2data_bar[p2data_bar$mtype=="AUPR", ], 
                   aes(x=class, y=value, fill=dataset)) +
  geom_bar(stat="identity", position=position_dodge(0.9),
           colour="black", size=0.1, width = 0.75) + 
  theme_bw() +  
  theme(legend.position = "bottom", 
        legend.title = element_blank(),
        legend.key.size = unit(0.25, "cm"),
        legend.text = element_text(size=6, family = "Arial"),
        legend.margin=margin(-7, 0, 0, 0),
        text=element_text(size = 7, family = "Arial"), 
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1),
        axis.text.x = element_text(angle = 0),
        axis.title.x = element_text(size = 7),
        axis.title.y = element_blank(), 
        plot.title = element_text(size=8, hjust = 0.5)) +
  scale_fill_manual(values = cbpl_2) + 
  scale_y_continuous(limits=c(0, 1), 
                     breaks=seq(0, 1, 0.2), 
                     expand = c(0, 0)) + 
  coord_cartesian(ylim = c(0.2, 1)) + 
  # geom_hline(yintercept=mean(p2data_bar[p2data_bar$mtype=="AUPR", ]$value), 
  #            linetype='dashed', col = 'black') +
  xlab("") + 
  ylab("") + 
  ggtitle("AUPR")
# p2_bar_2


grid_arrange_shared_legend <- function(..., ncol = length(list(...)), nrow = 1, position = c("bottom", "right")) {
  
  plots <- list(...)
  position <- match.arg(position)
  g <- ggplotGrob(plots[[1]] + theme(legend.position = position))$grobs
  legend <- g[[which(sapply(g, function(x) x$name) == "guide-box")]]
  lheight <- sum(legend$height)
  lwidth <- sum(legend$width)
  gl <- lapply(plots, function(x) x + theme(legend.position="none"))
  gl <- c(gl, ncol = ncol, nrow = nrow)
  
  combined <- switch(position,
                     "bottom" = arrangeGrob(do.call(arrangeGrob, gl),
                                            legend,
                                            ncol = 1,
                                            heights = unit.c(unit(1, "npc") - lheight, lheight)),
                     "right" = arrangeGrob(do.call(arrangeGrob, gl),
                                           legend,
                                           ncol = 2,
                                           widths = unit.c(unit(1, "npc") - lwidth, lwidth)))
  
  grid.newpage()
  grid.draw(combined)
  
  # return gtable invisibly
  invisible(combined)
  
}

p2_bar <- grid_arrange_shared_legend(p2_bar_1, p2_bar_2, ncol = 2)


png("fig3_auc_aupr.AUC.raw.png",
    width = 16.4,
    height = 5 + 0.2 + 5, units = "cm", res=ppi)
grid.arrange(arrangeGrob(p_auc_1, 
                         p_auc_2,
                         grid.rect(gp=gpar(col="white")),
                         p_aupr_1,
                         p_aupr_2,
                         ncol=5,
                         widths =c(2.2, 5.8, 0.4, 2.2, 5.8)), 
             grid.rect(gp=gpar(col="white")),
             arrangeGrob(p2_auroc, 
                         p2_aupr, 
                         grid.rect(gp=gpar(col="white")),
                         p2_bar,
                         ncol=4, 
                         widths =c(4.8, 4.8, 0.2, 6.6)), 
             nrow=3, 
             heights = c(5, 0.2, 5))
dev.off()





