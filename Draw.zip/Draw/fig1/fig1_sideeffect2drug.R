library(ggplot2)
library(scales)
# library(ggwordcloud)
library(extrafont)

library(UpSetR)
library(cowplot)


ppi= 500


# p1 =========================================================================
p1data <- read.table("task_1.txt", 
                    header = T, stringsAsFactors = F, sep = "\t")
colnames(p1data) <- c("drug", "side_effect", "assotype")

pse_sum <- table(p1data$side_effect)
pdata_sefreq <- as.data.frame(pse_sum)
colnames(pdata_sefreq) <- c("side_effect", "freq")

pdata_sefreq <- pdata_sefreq[order(-pdata_sefreq$freq),]
pdata_sefreq$secnt <- c(1:nrow(pdata_sefreq))
pdata_sefreq$seperc <- pdata_sefreq$secnt/nrow(pdata_sefreq) * 100
pdata_sefreq$assocum <- cumsum(pdata_sefreq$freq)
pdata_sefreq$assocum_perc <- pdata_sefreq$assocum/sum(pdata_sefreq$freq) * 100


breaks_minor = c(seq(0.02, 0.09, 0.01), 
                 seq(0.2, 0.9, 0.1), 
                 seq(2, 9, 1), 
                 seq(20, 90, 10))
labels_minor = rep("", length(breaks_minor))

# pdata_setfreq_wc <- pdata_sefreq[c(1:15),]
# pdata_setfreq_wc$secolour <- c(rep(1, 5), rep(0, nrow(pdata_setfreq_wc) - 5))

p1 <- ggplot() + 
  geom_line(data=pdata_sefreq, 
            aes(x=assocum_perc, y=seperc), colour="#f03b20", size=0.8) +  
  theme_bw() + 
  theme(legend.position = "none", 
        text=element_text(size = 8, family = "Arial"), 
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1), 
        panel.grid.minor = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 2), 
        axis.ticks.y = element_blank(), 
        axis.ticks.x = element_line(size=0.3),
        axis.ticks.length.x = unit(-3, "pt")) +
  scale_x_continuous(expand = c(0, 0), 
                     limits = c(-0.001, 100), 
                     breaks = seq(0, 100, 20), 
                     labels = seq(0, 100, 20), 
                     minor_breaks = NULL) + 
  scale_y_continuous(expand = c(0, 0),
                     limits = c(0.01, 100), 
                     minor_breaks = breaks_minor,
                     breaks = c(0.01, 0.1, 1, 10, 100), 
                     labels = c(0.01, 0.1, 1, 10, 100)) +
  coord_trans(y="log10") +
  xlab("Percentage of known interactions") + 
  ylab("Percentage of ADR terms") +
  annotation_logticks(base = 10,
                      sides = "lr",
                      outside = FALSE,
                      scaled = FALSE,
                      short = unit(1.5, "pt"),
                      mid = unit(1.5, "pt"),
                      long = unit(3, "pt"), 
                      size=0.3)
  # geom_text_wordcloud_area(data=pdata_setfreq_wc, 
  #                          aes(label=side_effect, size=freq, 
  #                              color = secolour), 
  #                          xlim=c(35, 99), 
  #                          ylim=c(0.015, 10), 
  #                          eccentricity = 0.7) + 
  # scale_size_area(max_size = 8) + 
  # scale_color_gradient(low = "black", high = "#f03b20")
# p1



png("fig1_sideeffect2drug.1.raw.png",
    width = 6,
    height = 7.5, units = "cm", res=ppi)
p1
dev.off()



# p2 ====================================================
p2data <- read.table("task_2.txt", 
                     header = T, stringsAsFactors = F, sep = "\t")
p2data$assocnt <- c(1:nrow(p2data))
p2label1 <- p2data[p2data$Label_1==1, c("assocnt")]
p2label2 <- p2data[p2data$Label_2==1, c("assocnt")]
p2label3 <- p2data[p2data$Label_3==1, c("assocnt")]
p2label4 <- p2data[p2data$Label_4==1, c("assocnt")]
p2label5 <- p2data[p2data$Label_5==1, c("assocnt")]
p2label6 <- p2data[p2data$Label_6==1, c("assocnt")]
p2label7 <- p2data[p2data$Label_7==1, c("assocnt")]


p2data_sets <- list(OT=p2label1, 
                    RI=p2label2,
                    CA=p2label3,
                    DS=p2label4,
                    HO=p2label5,
                    LT=p2label6,
                    DE=p2label7)

# plot venn with UpSetR =================
p2_upsets <- upset(fromList(p2data_sets), 
                   sets = c("OT", "RI", "CA", "DS", 
                            "HO", "LT", "DE"), 
                  order.by = "freq", 
                  keep.order = TRUE,
                  empty.intersections = NULL,
                  point.size = 1.5, line.size = 0.8,
                  mainbar.y.label = "Intersection size", sets.x.label = "Set size", 
                  matrix.color = "#f03b20", main.bar.color = "#f03b20",
                  sets.bar.color = "#f03b20", text.scale = c(1.2, 1.0, 0.8, 0.8, 1.2, 0.6), 
                  mb.ratio = c(0.75, 0.25), show.numbers = "yes", nintersects = 40, 
                  number.angles = 0, 
                  scale.intersections="identity", set_size.show=FALSE)


png("fig1_sideeffect2drug.2.raw.png",
    width = 10*1.5,
    height = 8.0*1.5, units = "cm", res=ppi)
p2_upsets
dev.off()


p2data_bar <- data.frame(label= c("Label7", "Label6", "Label5", "Label4", "Label3", 
                              "Label2", "Label1"), 
                         lname = c("DE", "LT", "HO", "DS", 
                                   "CA", "RI", "OT"),
                         
                         count= c(sum(p2data$Label_7==1), sum(p2data$Label_6==1), 
                                  sum(p2data$Label_5==1), sum(p2data$Label_4==1), 
                                  sum(p2data$Label_3==1), sum(p2data$Label_2==1), 
                                  sum(p2data$Label_1==1)))
p2data_bar$lname = factor(p2data_bar$lname, levels = c("DE", "LT", "HO", "DS", 
                                                       "CA", "RI", "OT"))


p2_bar <- ggplot(data=p2data_bar, aes(x=lname, y=count)) + 
  geom_bar(fill="#91bfdb", colour="black", stat="identity", size=0.2, 
           position=position_dodge(0.7)) +  
  theme_bw() + 
  theme(legend.position = "none", 
        text=element_text(size = 6, family = "Arial"), 
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1), 
        panel.grid.minor = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 2), 
        axis.text.x = element_text(angle = 0),
        axis.title.x = element_blank(), 
        axis.title.y = element_text(size = 7)) +
  xlab("") + 
  ylab("Number of samples")
p2_bar


png("fig1_sideeffect2drug.2.raw.plus.png",
    width = 3.8,
    height = 4.5, units = "cm", res=ppi)
p2_bar
dev.off()






