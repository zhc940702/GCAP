library(ggplot2)
library(scales)
library(reshape2)
library(extrafont)
library(grid)
library(gridExtra)


ppi = 500


cbpl_2 <- c("#abdda4", "#d7191c")


grid_arrange_shared_legend <- function(..., ncol = length(list(...)), nrow = 1, position = c("bottom", "right")) {
  
  plots <- list(...)
  position <- match.arg(position)
  g <- ggplotGrob(plots[[1]] + theme(legend.position = position))$grobs
  legend <- g[[which(sapply(g, function(x) x$name) == "guide-box")]]
  lheight <- sum(legend$height)
  lwidth <- sum(legend$width)
  gl <- lapply(plots, function(x) x + theme(legend.position="none"))
  gl <- c(gl, ncol = ncol, nrow = nrow)
  
  combined <- switch(position,
                     "bottom" = arrangeGrob(do.call(arrangeGrob, gl),
                                            legend,
                                            ncol = 1,
                                            heights = unit.c(unit(1, "npc") - lheight, lheight)),
                     "right" = arrangeGrob(do.call(arrangeGrob, gl),
                                           legend,
                                           ncol = 2,
                                           widths = unit.c(unit(1, "npc") - lwidth, lwidth)))
  
  grid.newpage()
  grid.draw(combined)
  
  # return gtable invisibly
  invisible(combined)
  
}



# ============================ plot

pdata <- read.table("fig6_enhance.metric.txt", 
                    header = T, sep = "\t", stringsAsFactors = F)
pdata$modify <- factor(pdata$modify, levels = c("No", "Yes"))
unique(pdata$type)


# ddi ==============================================
pdata_ddi <- pdata[pdata$type == "Drug-Drug Interaction", ]
unique(pdata_ddi$metric)

p_ddi_acc <- ggplot(data=pdata_ddi[pdata_ddi$metric == "ACC", ], 
                    aes(x=method, y=value, fill=modify)) + 
  geom_bar(stat="identity", position=position_dodge(0.9),
           colour="black", size=0.2) + 
  theme_bw() + 
  theme(legend.position = "bottom", 
        legend.title = element_blank(), 
        legend.margin=margin(-1, 0, 0, 0),
        legend.key.size = unit(0.35, "cm"),
        legend.text = element_text(size=7, family = "Arial"),
        text=element_text(size = 7, family = "Arial"), 
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1),
        axis.text.x = element_text(angle = 0),
        axis.title.x = element_text(size = 7),
        axis.title.y = element_blank(), 
        plot.title = element_text(size=7, hjust = 0.5)) + 
  scale_fill_manual(values = cbpl_2, 
                    breaks = c("No", "Yes"),
                    labels = c("Original      ", "Modified")) + 
  scale_y_continuous(limits=c(0, 1), 
                     breaks=seq(0, 1, 0.05), 
                     expand = c(0, 0)) + 
  coord_cartesian(ylim = c(0.6, 1)) + 
  xlab("") + 
  ylab("") + 
  ggtitle("ACC")

p_ddi_f1 <- ggplot(data=pdata_ddi[pdata_ddi$metric == "Macro F1", ], 
                    aes(x=method, y=value, fill=modify)) + 
  geom_bar(stat="identity", position=position_dodge(0.9),
           colour="black", size=0.2) + 
  theme_bw() + 
  theme(legend.position = "bottom", 
        legend.title = element_blank(), 
        legend.margin=margin(-1, 0, 0, 0),
        legend.key.size = unit(0.35, "cm"),
        legend.text = element_text(size=7, family = "Arial"),
        text=element_text(size = 7, family = "Arial"), 
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1),
        axis.text.x = element_text(angle = 0),
        axis.title.x = element_text(size = 7),
        axis.title.y = element_blank(), 
        plot.title = element_text(size=7, hjust = 0.5)) + 
  scale_fill_manual(values = cbpl_2, 
                    breaks = c("No", "Yes"),
                    labels = c("Original      ", "Modified")) + 
  scale_y_continuous(limits=c(0, 1), 
                     breaks=seq(0, 1, 0.05), 
                     expand = c(0, 0)) + 
  coord_cartesian(ylim = c(0.6, 1)) + 
  xlab("") + 
  ylab("") + 
  ggtitle("Macro F1")

# p_ddi <- grid_arrange_shared_legend(p_ddi_acc, p_ddi_f1, ncol = 2, nrow = 1) 




# dci ==============================================
pdata_dci <- pdata[pdata$type == "Drug-Cell interaction", ]
unique(pdata_dci$metric)

p_dci_rmse <- ggplot(data=pdata_dci[pdata_dci$metric == "RMSE", ], 
                    aes(x=method, y=value, fill=modify)) + 
  geom_bar(stat="identity", position=position_dodge(0.9),
           colour="black", size=0.2) + 
  theme_bw() + 
  theme(legend.position = "bottom", 
        legend.title = element_blank(), 
        legend.margin=margin(-1, 0, 0, 0),
        legend.key.size = unit(0.35, "cm"),
        legend.text = element_text(size=7, family = "Arial"),
        text=element_text(size = 7, family = "Arial"), 
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1),
        axis.text.x = element_text(size = c(4, 5, 5)),
        axis.title.x = element_text(size = 7),
        axis.title.y = element_blank(), 
        plot.title = element_text(size=7, hjust = 0.5)) + 
  scale_fill_manual(values = cbpl_2, 
                    breaks = c("No", "Yes"),
                    labels = c("Original      ", "Modified")) + 
  scale_y_continuous(limits=c(0, 1.5), 
                     breaks=seq(0, 1.5, 0.1), 
                     labels = format(round(seq(0, 1.5, 0.1), 2), nsmall = 2),
                     expand = c(0, 0)) + 
  coord_cartesian(ylim = c(0.7, 1.5)) + 
  xlab("") + 
  ylab("") + 
  ggtitle("RMSE")

p_dci_mae <- ggplot(data=pdata_dci[pdata_dci$metric == "MAE", ], 
                     aes(x=method, y=value, fill=modify)) + 
  geom_bar(stat="identity", position=position_dodge(0.9),
           colour="black", size=0.2) + 
  theme_bw() + 
  theme(legend.position = "bottom", 
        legend.title = element_blank(), 
        legend.margin=margin(-1, 0, 0, 0),
        legend.key.size = unit(0.35, "cm"),
        legend.text = element_text(size=7, family = "Arial"),
        text=element_text(size = 7, family = "Arial"), 
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1),
        axis.text.x = element_text(size = c(4, 5, 5)),
        axis.title.x = element_text(size = 7),
        axis.title.y = element_blank(), 
        plot.title = element_text(size=7, hjust = 0.5)) + 
  scale_fill_manual(values = cbpl_2, 
                    breaks = c("No", "Yes"),
                    labels = c("Original      ", "Modified")) + 
  scale_y_continuous(limits=c(0, 1), 
                     breaks=seq(0, 1, 0.1), 
                     labels = format(round(seq(0, 1, 0.1), 2), nsmall = 2),
                     expand = c(0, 0)) + 
  coord_cartesian(ylim = c(0.5, 0.9)) + 
  xlab("") + 
  ylab("") + 
  ggtitle("MAE")


# p_dci <- grid_arrange_shared_legend(p_dci_rmse, p_dci_mae, ncol = 2, nrow = 1)


# dse ==============================================
pdata_dse <- pdata[pdata$type == "Drug-side effect frequency", ]
unique(pdata_dse$metric)

p_dse_auc <- ggplot(data=pdata_dse[pdata_dse$metric == "AUC", ], 
                    aes(x=method, y=value, fill=modify)) + 
  geom_bar(stat="identity", position=position_dodge(0.9),
           colour="black", size=0.2) + 
  theme_bw() + 
  theme(legend.position = "bottom", 
        legend.title = element_blank(), 
        legend.margin=margin(-1, 0, 0, 0),
        legend.key.size = unit(0.35, "cm"),
        legend.text = element_text(size=7, family = "Arial"),
        text=element_text(size = 7, family = "Arial"), 
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1),
        axis.text.x = element_text(angle = 0),
        axis.title.x = element_text(size = 7),
        axis.title.y = element_blank(), 
        plot.title = element_text(size=7, hjust = 0.5)) + 
  scale_fill_manual(values = cbpl_2, 
                    breaks = c("No", "Yes"),
                    labels = c("Original      ", "Modified")) + 
  scale_y_continuous(limits=c(0, 1), 
                     breaks=seq(0, 1, 0.05), 
                     expand = c(0, 0)) + 
  coord_cartesian(ylim = c(0.6, 1)) + 
  xlab("") + 
  ylab("") + 
  ggtitle("AUC")
# p_dse_auc


p_dse_aupr <- ggplot(data=pdata_dse[pdata_dse$metric == "AUPR", ], 
                    aes(x=method, y=value, fill=modify)) + 
  geom_bar(stat="identity", position=position_dodge(0.9),
           colour="black", size=0.2) + 
  theme_bw() + 
  theme(legend.position = "bottom", 
        legend.title = element_blank(), 
        legend.margin=margin(-1, 0, 0, 0),
        legend.key.size = unit(0.35, "cm"),
        legend.text = element_text(size=7, family = "Arial"),
        text=element_text(size = 7, family = "Arial"), 
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1),
        axis.text.x = element_text(angle = 0),
        axis.title.x = element_text(size = 7),
        axis.title.y = element_blank(), 
        plot.title = element_text(size=7, hjust = 0.5)) + 
  scale_fill_manual(values = cbpl_2, 
                    breaks = c("No", "Yes"),
                    labels = c("Original      ", "Modified")) + 
  scale_y_continuous(limits=c(0, 1), 
                     breaks=seq(0, 1, 0.05), 
                     expand = c(0, 0)) + 
  coord_cartesian(ylim = c(0.6, 1)) + 
  xlab("") + 
  ylab("") + 
  ggtitle("AUPR")
# p_dse_aupr


p_dse_rmse <- ggplot(data=pdata_dse[pdata_dse$metric == "RMSE", ], 
                     aes(x=method, y=value, fill=modify)) + 
  geom_bar(stat="identity", position=position_dodge(0.9),
           colour="black", size=0.2) + 
  theme_bw() + 
  theme(legend.position = "bottom", 
        legend.title = element_blank(), 
        legend.margin=margin(-1, 0, 0, 0),
        legend.key.size = unit(0.35, "cm"),
        legend.text = element_text(size=7, family = "Arial"),
        text=element_text(size = 7, family = "Arial"), 
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1),
        axis.text.x = element_text(angle = 0),
        axis.title.x = element_text(size = 7),
        axis.title.y = element_blank(), 
        plot.title = element_text(size=7, hjust = 0.5)) + 
  scale_fill_manual(values = cbpl_2, 
                    breaks = c("No", "Yes"),
                    labels = c("Original      ", "Modified")) + 
  scale_y_continuous(limits=c(0, 1), 
                     breaks=seq(0, 1, 0.05), 
                     expand = c(0, 0)) + 
  coord_cartesian(ylim = c(0.3, 0.75)) + 
  xlab("") + 
  ylab("") + 
  ggtitle("RMSE")
# p_dse_rmse


p_dse_mae <- ggplot(data=pdata_dse[pdata_dse$metric == "MAE", ], 
                     aes(x=method, y=value, fill=modify)) + 
  geom_bar(stat="identity", position=position_dodge(0.9),
           colour="black", size=0.2) + 
  theme_bw() + 
  theme(legend.position = "bottom", 
        legend.title = element_blank(), 
        legend.margin=margin(-1, 0, 0, 0),
        legend.key.size = unit(0.35, "cm"),
        legend.text = element_text(size=7, family = "Arial"),
        text=element_text(size = 7, family = "Arial"), 
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1),
        axis.text.x = element_text(angle = 0),
        axis.title.x = element_text(size = 7),
        axis.title.y = element_blank(), 
        plot.title = element_text(size=7, hjust = 0.5)) + 
  scale_fill_manual(values = cbpl_2, 
                    breaks = c("No", "Yes"),
                    labels = c("Original      ", "Modified")) + 
  scale_y_continuous(limits=c(0, 1), 
                     breaks=seq(0, 1, 0.05), 
                     expand = c(0, 0)) + 
  coord_cartesian(ylim = c(0.3, 0.55)) + 
  xlab("") + 
  ylab("") + 
  ggtitle("MAE")
# p_dse_mae


# p_dse <- grid_arrange_shared_legend(p_dse_auc, p_dse_aupr, p_dse_rmse, p_dse_mae, ncol = 4, nrow = 1)



g_legend<-function(a.gplot){
  tmp <- ggplot_gtable(ggplot_build(a.gplot))
  leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
  legend <- tmp$grobs[[leg]]
  return(legend)}
p_legend <- g_legend(p_ddi_acc)


png("fig6_enhance.metric.raw.png",
    width = 7 + 7 + 0.2,
    height = 6 + 6 + 1.5, units = "cm", res=ppi)
grid.arrange(grid.rect(gp=gpar(col="white")),
             arrangeGrob(p_ddi_acc + theme(legend.position = "none"), 
                         p_ddi_f1 + theme(legend.position = "none"), 
                         grid.rect(gp=gpar(col="white")),
                         p_dci_rmse + theme(legend.position = "none"),
                         p_dci_mae + theme(legend.position = "none"),
                         ncol = 5, 
                         widths = c(3.5, 3.5, 0.2, 3.5, 3.5)), 
             grid.rect(gp=gpar(col="white")),
             arrangeGrob(p_dse_auc + theme(legend.position = "none"),
                         p_dse_aupr + theme(legend.position = "none"), 
                         grid.rect(gp=gpar(col="white")),
                         p_dse_rmse + theme(legend.position = "none"),
                         p_dse_mae + theme(legend.position = "none"), 
                         ncol = 5, 
                         widths = c(3.5, 3.5, 0.2, 3.5, 3.5)), 
             p_legend,
             nrow=5, 
             heights = c(0.5, 6, 0.5, 6, 0.5))
dev.off()



