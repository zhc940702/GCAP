library(ggplot2)
library(scales)
library(reshape2)
library(extrafont)
library(grid)
library(gridExtra)


ppi = 500
cbpl_7 <- c("#377eb8", "#4daf4a", "#984ea3", "#ff7f00", 
            "#999999", "#a65628", "#f781bf")
cbpl_2 <- c("#8dd3c7", "#bebada")

subtypes <- c("DE", "LT", "HO", "DS", 
  "CA", "RI", "OT")


grid_arrange_shared_legend <- function(..., ncol = length(list(...)), nrow = 1, position = c("bottom", "right")) {
  
  plots <- list(...)
  position <- match.arg(position)
  g <- ggplotGrob(plots[[1]] + theme(legend.position = position))$grobs
  legend <- g[[which(sapply(g, function(x) x$name) == "guide-box")]]
  lheight <- sum(legend$height)
  lwidth <- sum(legend$width)
  gl <- lapply(plots, function(x) x + theme(legend.position="none"))
  gl <- c(gl, ncol = ncol, nrow = nrow)
  
  combined <- switch(position,
                     "bottom" = arrangeGrob(do.call(arrangeGrob, gl),
                                            legend,
                                            ncol = 1,
                                            heights = unit.c(unit(1, "npc") - lheight, lheight)),
                     "right" = arrangeGrob(do.call(arrangeGrob, gl),
                                           legend,
                                           ncol = 2,
                                           widths = unit.c(unit(1, "npc") - lwidth, lwidth)))
  
  grid.newpage()
  grid.draw(combined)
  
  # return gtable invisibly
  invisible(combined)
  
}



# ========================================== boxplot

p1data <- read.table("fig4_denovo.auc_aupr1.txt", 
                     header = F, sep = "\t", stringsAsFactors = F)
colnames(p1data) <- c("mclass", "variable", "value")
p1data[p1data$mclass == "Task_1", ]$mclass = "task1"
p1data[p1data$mclass == "Label_7", ]$mclass = subtypes[1]
p1data[p1data$mclass == "Label_6", ]$mclass = subtypes[2]
p1data[p1data$mclass == "Label_5", ]$mclass = subtypes[3]
p1data[p1data$mclass == "Label_4", ]$mclass = subtypes[4]
p1data[p1data$mclass == "Label_3", ]$mclass = subtypes[5]
p1data[p1data$mclass == "Label_2", ]$mclass = subtypes[6]
p1data[p1data$mclass == "Label_1", ]$mclass = subtypes[7]
p1data$mclass <- factor(p1data$mclass, levels = c("task1", 
                                                  "DE", "LT", "HO", "DS", 
                                                  "CA", "RI", "OT"))



p1_box1 <- ggplot(p1data[p1data$mclass == "task1", ], 
                  aes(x=mclass, y=value, fill=variable)) + 
  stat_boxplot(aes(group=interaction(mclass, variable)), geom = "errorbar", 
               size=0.3) +
  geom_boxplot(lwd=0.3, outlier.size=0.15, fatten=1) + # 0.5
  theme_bw() + 
  theme(legend.position = "bottom", 
        legend.title = element_blank(), 
        legend.margin=margin(-1, 0, 0, 0),
        legend.key.size = unit(0.35, "cm"),
        legend.text = element_text(size=7, family = "Arial"),
        text=element_text(size = 7, family = "Arial"), 
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1),
        axis.title.x = element_text(),
        axis.title.y = element_blank(), 
        plot.title = element_text(size=8, hjust = 0.5)) +
  scale_fill_manual(values = cbpl_2, 
                    labels = c("AUC      ", "AUPR")) + 
  scale_x_discrete(labels = c("Serious")) +
  scale_y_continuous(limits=c(0, 1), 
                     breaks=seq(0, 1, 0.2), 
                     expand = c(0, 0)) +
  xlab("") + 
  ylab("") + 
  ggtitle("Task1")
# p1_box1


p1_box2 <- ggplot(p1data[p1data$mclass != "task1", ], 
                  aes(x=mclass, y=value, fill=variable)) + 
  stat_boxplot(aes(group=interaction(mclass, variable)), geom = "errorbar", 
               size=0.3) +
  geom_boxplot(lwd=0.3, outlier.size=0.15, fatten=1) + # 0.5
  theme_bw() + 
  theme(legend.position = "bottom", 
        legend.title = element_blank(), 
        legend.margin=margin(-1, 0, 0, 0),
        legend.key.size = unit(0.35, "cm"),
        legend.text = element_text(size=7, family = "Arial"),
        text=element_text(size = 7, family = "Arial"), 
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1),
        axis.title.x = element_text(),
        axis.title.y = element_blank(), 
        plot.title = element_text(size=8, hjust = 0.5)) +
  scale_fill_manual(values = cbpl_2, 
                    labels = c("AUC      ", "AUPR")) + 
  scale_y_continuous(limits=c(0, 1), 
                     breaks=seq(0, 1, 0.2), 
                     expand = c(0, 0)) +
  xlab("") + 
  ylab("") + 
  ggtitle("Task2")
# p1_box2







# ========================================== barplot 1 
p2data_1 <- read.table("fig4_denovo.auc_aupr2.1.txt", 
                       header = T, sep = "\t", stringsAsFactors = F)
p2data_1m <- melt(p2data_1, id.vars = c("Associations.removed"))

p2_bar_1 <- ggplot(data = p2data_1m, 
                   aes(x=Associations.removed, y=value, fill=variable, width=.8)) +
  geom_bar(stat="identity", position=position_dodge(0.9),
           colour="black", size=0.2) + 
  theme_bw() +  
  theme(legend.position = "bottom", 
        legend.title = element_blank(), 
        legend.margin=margin(-1, 0, 0, 0),
        legend.key.size = unit(0.35, "cm"),
        legend.text = element_text(size=7, family = "Arial"),
        text=element_text(size = 7, family = "Arial"), 
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1),
        axis.text.x = element_text(angle = 0),
        axis.title.x = element_text(size = 7),
        axis.title.y = element_blank(), 
        plot.title = element_text(size=8, hjust = 0.5)) +
  scale_fill_manual(values = cbpl_2, 
                    labels = c("AUC      ", "AUPR")) + 
  scale_y_continuous(limits=c(0, 1), 
                     breaks=seq(0, 1, 0.2), 
                     expand = c(0, 0)) + 
  xlab("Interactions removed") + 
  ylab("") + 
  ggtitle("Task1")
# p2_bar_1


# ========================================== barplot 2
p2data_2 <- read.table("fig4_denovo.auc_aupr2.2.txt", 
                       header = T, sep = "\t", stringsAsFactors = F)
p2data_2m <- melt(p2data_2, id.vars = c("Associations.removed"))
p2_bar_2 <- ggplot(data = p2data_2m, 
                   aes(x=Associations.removed, y=value, fill=variable, width=.8)) +
  geom_bar(stat="identity", position=position_dodge(0.9),
           colour="black", size=0.2) + 
  theme_bw() +  
  theme(legend.position = "bottom", 
        legend.title = element_blank(), 
        legend.margin=margin(-1, 0, 0, 0),
        legend.key.size = unit(0.35, "cm"),
        legend.text = element_text(size=7, family = "Arial"),
        text=element_text(size = 7, family = "Arial"), 
        panel.grid.major = element_line(color = "grey",
                                        size = 0.3,
                                        linetype = 1),
        axis.text.x = element_text(angle = 0),
        axis.title.x = element_text(size = 7),
        axis.title.y = element_blank(), 
        plot.title = element_text(size=8, hjust = 0.5)) +
  scale_fill_manual(values = cbpl_2, 
                    labels = c("AUC      ", "AUPR")) + 
  scale_y_continuous(limits=c(0, 1), 
                     breaks=seq(0, 1, 0.2), 
                     expand = c(0, 0)) + 
  xlab("Interactions removed") + 
  ylab("") + 
  ggtitle("Task2")
# p2_bar_2


# p2_bar <- grid_arrange_shared_legend(p2_bar_1, p2_bar_2, ncol = 2, nrow = 1)



g_legend<-function(a.gplot){
  tmp <- ggplot_gtable(ggplot_build(a.gplot))
  leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
  legend <- tmp$grobs[[leg]]
  return(legend)}
p1_legend <- g_legend(p1_box1)
p2_legend <- g_legend(p2_bar_1)


png("fig4_denovo.auc_aupr.raw.png",
    width = 18,
    height = 6, units = "cm", res=ppi)
grid.arrange(arrangeGrob(arrangeGrob(p2_bar_1 + theme(legend.position = "none"), 
                                     p2_bar_2 + theme(legend.position = "none"), 
                                     ncol=2, 
                                     widths = c(1, 1)),
                         p2_legend,
                         nrow=2, 
                         heights = c(5.7, 0.3)), 
             grid.rect(gp=gpar(col="white")),
             arrangeGrob(arrangeGrob(p1_box1 + theme(legend.position = "none"), 
                                     p1_box2 + theme(legend.position = "none"), 
                                     ncol=2, 
                                     widths = c(2, 8)),
                         p1_legend,
                         nrow=2, 
                         heights = c(5.7, 0.3)), 
             ncol=3, 
             widths = c(7.8, 0.2, 10))
dev.off()